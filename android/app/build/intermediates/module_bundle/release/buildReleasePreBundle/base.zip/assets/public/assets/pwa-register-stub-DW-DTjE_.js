const e=e=>({update(){},needRefresh:!1,offlineReady:!1});export{e as default,e as registerSW};
