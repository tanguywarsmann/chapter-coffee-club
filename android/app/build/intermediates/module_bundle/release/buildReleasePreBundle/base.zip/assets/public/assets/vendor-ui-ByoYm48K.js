function e(e,t,{checkForDefaultPrevented:n=!0}={}){return function(r){if(e?.(r),!1===n||!r.defaultPrevented)return t?.(r)}}function t(e,[t,n]){return Math.min(n,Math.max(t,e))}export{t as a,e as c};
